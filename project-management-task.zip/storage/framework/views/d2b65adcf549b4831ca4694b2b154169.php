<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('projects.index')); ?>" type="button" class="btn btn-primary mb-3">View</a>
<div class="">
    <form id="form" enctype="multipart/form-data">
        <div class="mb-3">
            <?php echo csrf_field(); ?>
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="text" name="name" value="<?php echo e($project->name); ?>" class="form-control"
                id="exampleFormControlInput1" placeholder="">
        </div>

        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Description</label>
            <textarea name="description" class="form-control" id="exampleFormControlTextarea1" rows="3">
                <?php echo e($project->description); ?>

            </textarea>
        </div>
        <div class="mb-3 form-check">
            <input type="date" value="<?php echo e($project->start_date); ?>" name="start_date" class="form-label"
                id="exampleCheck1">
        </div>
        <div class="mb-3 form-check">
            <input type="file" multiple name="attachments[]" class="form-label" id="exampleCheck1">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>


<div class="row mt-3">
    <?php $__currentLoopData = $project->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
        <img src=<?php echo e(asset('public/images/'.$attachment->path)); ?> />
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
<script>
    $('#form').on('submit', function(e) {
        e.preventDefault();
        var data = new FormData(document.getElementById('form'));
        data.append("_method", "PUT")
        $.ajax({
        type: 'POST',
        url: "<?php echo e(route('projects.update', $project)); ?>",
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        data: data,
        success: function(response) {
        console.log(response);
        if (response.code == 200) {
       Toastify({
        text: `${response.message}`,
        className: "success",
        position: "center",
        }).showToast();

        setTimeout(() => {
            window.location.href = "/projects"
        }, 2000)

        }
        },
        error: function(error) {
        console.log(error.responseText);
        }
        });
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\company-task\project-management\resources\views/projects/edit.blade.php ENDPATH**/ ?>