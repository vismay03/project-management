


<?php $__env->startSection('content'); ?>
<div>
    <a href="<?php echo e(route('projects.index')); ?>" type="button" class="btn btn-primary mb-3">View</a>
    <div class="card">
        <div class="card-body">
           

            <p class="card-text"> <small>Project Name: </small><?php echo e($project->name); ?></p>
            <p class="card-text"> <small>Project Description: </small> <?php echo e($project->description); ?></p>
            <p class="card-text"> <small class="text-muted">Start Date: <?php echo e($project->start_date); ?></small></p>

            <a href="" type="button" class="btn btn-primary mb-3">Add task</a>
        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\company-task\project-management\resources\views/projects/show.blade.php ENDPATH**/ ?>