<table class="table">
    <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Total Task</th>
        </tr>
    </thead>
    <tbody id="show">

        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>

            <td><?php echo e($project->name); ?></td>
            <td><?php echo e($project->description); ?></td>
            <td><?php echo e($project->tasks_count); ?></td>
            <td class="action">
                <a href="<?php echo e(route('projects.edit', $project)); ?>" type="button" class="btn   btn-primary">Edit</a>

                <button  href="<?php echo e(route('projects.destroy', $project)); ?>"   type="button" id="delete"
                    class="btn  btn-danger">Delete</button>

                    <a href="<?php echo e(route('projects.show', $project)); ?>" type="button" class="btn   btn-primary">Details</a>

            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<div class="col-md-6">

    <?php echo e($projects->links()); ?>

</div>
<?php /**PATH C:\company-task\project-management\resources\views/projects/table.blade.php ENDPATH**/ ?>